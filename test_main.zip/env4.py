import gym
import math
import numpy as np
from gymnasium import spaces
from xarm.wrapper import XArmAPI
from gymnasium_robotics.core import GoalEnv
import os
# 리워드 고도화, 액션 변경
import torch
print(torch.cuda.is_available())  # True가 출력되어야 함
print(torch.cuda.get_device_name(0))  # GPU 이름 출력

JOINT_LIMIT =  [
    (-2 * math.pi, 2 * math.pi),
    (-2.61799, 2.61799),
    (-0.0610865, 5.23599),
    (-2 * math.pi, 2 * math.pi),
    (-2.16421, 2.16421),
    (-2 * math.pi, 2 * math.pi)
]
#길이 6정도 리스트고, 각 원소는 min_limit, max_limit 형태 튜플임.

class XArmEnv(GoalEnv):
    def __init__(self, use_demonstrations=True, max_episodes_for_demo=1000):
        super(XArmEnv, self).__init__()
        self.arm = XArmAPI('192.168.1.162')
        self.arm.motion_enable(enable=True)
        self.arm.set_mode(0)
        self.arm.set_state(state=0)
        print('initializing with state:', self.arm.get_state())
        self._max_episode_steps = 100
        self.goal_space = spaces.Box(
            low=np.array([260, 190, 250, -170, -90, 0]), 
            high=np.array([270, 200, 260, -155, -80, 10]),
            dtype='float32'
        )
        self.goal = self._sample_goal()
        obs = self._get_obs()
        self.action_space = spaces.Box(low=-50, high=50, shape=(3,), dtype='float32')
        self.observation_space = spaces.Dict({
            'observation': spaces.Box(-np.inf, np.inf, shape=obs['observation'].shape, dtype='float32'),
            'achieved_goal': spaces.Box(-np.inf, np.inf, shape=obs['achieved_goal'].shape, dtype='float32'),
            'desired_goal': spaces.Box(-np.inf, np.inf, shape=obs['desired_goal'].shape, dtype='float32'),
        })
        self.use_demonstrations = use_demonstrations
        self.demonstrations = None
        self.current_episode = 0  # (주석) 현재 에피소드 카운트
        self.max_episodes_for_demo = max_episodes_for_demo  # (주석) 이 에피소드 수 이후로는 데모 사용량 감소

        if self.use_demonstrations:
            self._load_demonstrations() # (주석) CSV에서 데모 로드
            
    def _sample_goal(self):
        """
        목표(goal) 공간 내에서 무작위로 목표를 샘플링하는 메서드
        """
        goal = np.random.uniform(self.goal_space.low, self.goal_space.high)
        return goal

    def _load_demonstrations(self):
        # (주석) demonstration csv 파일 로드
        demo_path = "./pumping_interpolated_trajectory.csv"
        if os.path.exists(demo_path):
            self.demonstrations = np.loadtxt(demo_path, delimiter=",", skiprows=1)
            print("Demonstration data loaded:", self.demonstrations.shape)
        else:
            print("No demonstration data found. Proceeding without it.")
            self.demonstrations = None

    def step(self, action):
        # 이전 상태와 현재 상태 계산
        prev_state = self._get_obs()

        # 액션 적용
        action = np.clip(action, self.action_space.low, self.action_space.high)
        self.arm.set_position(*action, relative=True, wait=True)
        
        # 새로운 상태를 가져오고, 시간에 따른 변화 반영
        curr_state = self._get_obs()
        
        # 상태 변화 (delta 상태) 계산
        delta_state = curr_state['observation'] - prev_state['observation']

        # 충돌 감지
        #collision_detected = False #self.arm.set_self_collision_detection
        ext_force = self.arm.ft_ext_force   # 이게 예를 들어 외력 측정값이라면
        # 특정 threshold 이상이면 충돌로 간주
        force_threshold = 10.0
        collision_detected = np.linalg.norm(ext_force) > force_threshold

        # 진행 상황 및 목표 도달 여부를 계산
        info = {
            'is_success': self._is_success(curr_state['achieved_goal'], self.goal),
            'future_length': self._max_episode_steps - self.num_steps,
            'state_change': np.linalg.norm(delta_state),  # 상태 변화량
            'collision': collision_detected }  # 충돌 여부 추가}

        # 보상 계산
        reward = self.compute_reward(curr_state['achieved_goal'], self.goal, info, action)

        # 종료 여부 체크
        done = self.num_steps == self._max_episode_steps
        return curr_state, reward, done, False, info

    def reset(self, seed=None, maybe_options=None, options2=None):
        super(XArmEnv, self).reset(seed=seed, options=maybe_options)
        self.arm.set_servo_angle(angle=[118.61103,45.350011,45.358376,2.625751,-73.658767,-76.091316], wait=True)
        import time
        time.sleep(5)
        self.goal = self._sample_goal()
        self.num_steps = 0
        # (주석) 에피소드 카운트 증가
        self.current_episode += 1
        return self._get_obs(), {}
  
    def compute_reward(self, achieved_goal, desired_goal, info, action=None):
        # 리워드 초기화
        reward = 0
        
        #관절 상태 기반 패널티 계산 (JOINT_LIMIT 활용)
        try:
            joint_angles = self.arm.get_servo_angle()[1]  # joint_angles는 [angle_1, angle_2, ..., angle_6] 형태라고 가정
            joint_penalty = 0.0
            for angle, (min_limit, max_limit) in zip(joint_angles, JOINT_LIMIT):
                # 각도가 최소 범위보다 작을 경우 초과하는 만큼 페널티
                if angle < min_limit:
                    joint_penalty += (min_limit - angle)
                # 각도가 최대 범위보다 클 경우 초과하는 만큼 페널티
                elif angle > max_limit:
                    joint_penalty += (angle - max_limit)
            reward -= 0.1 * joint_penalty
        except Exception as e:
            print(f"Joint angle error: {e}")
            
        # 목표와 현재 위치(achieved_goal) 간 거리 (x, y, z만 사용) 맞는건지 확신은 없음
        position_distance = np.linalg.norm(achieved_goal[:3] - desired_goal[:3])
        max_position_distance = np.linalg.norm(self.goal_space.high[:3] - self.goal_space.low[:3])

        # 목표 거리 기반 보상
        reward -= position_distance
        if position_distance < 0.1:
            reward += 5 * (0.1 - position_distance)
        elif position_distance < 0.5:
            reward += 0.5 * (0.5 - position_distance)

        # 방향성 보상 계산 시 목표와 현재 성취 좌표의 첫 3차원만 사용
        if action is not None and position_distance > 1e-3:
            direction_vector = desired_goal[:3] - achieved_goal[:3]
            direction_norm = np.linalg.norm(direction_vector)
            if direction_norm > 1e-6:
                # direction_vector와 action을 이용한 방향성 보상
                direction_reward = np.dot(action, direction_vector) / direction_norm
                reward += 0.01 * direction_reward

                # 단위벡터로 정규화한 방향성 보상 (이거 계산 잘못해서 0나오면 에러생긴다고 해서 넣음.)
                direction_unit_vector = direction_vector / direction_norm
                action_norm = np.linalg.norm(action)
                if action_norm > 1e-6:
                    action_unit_vector = action / action_norm
                    direction_reward = np.dot(action_unit_vector, direction_unit_vector)
                    reward += 0.01 * direction_reward

        # 데몬스트레이션 기반 보상 (여기서도 direction 관련 계산 시 첫 3차원만 사용)
        if self.demonstrations is not None:
            demo_weight = max(0, 1 - (self.current_episode - self.max_episodes_for_demo) / self.max_episodes_for_demo)
            if demo_weight > 0:
                demo_positions = self.demonstrations[:, :3]
                agent_pos = achieved_goal[:3]
                max_distance = np.linalg.norm(self.goal_space.high[:3] - self.goal_space.low[:3])
                # 여기서도 desired_goal[:3]와 achieved_goal[:3] 사용
                dg_ag_vector = (desired_goal[:3] - achieved_goal[:3])
                dg_ag_norm = np.linalg.norm(dg_ag_vector)
                if action is not None and dg_ag_norm > 1e-6:
                    direction_reward = np.dot(action, dg_ag_vector) / dg_ag_norm
                    similarity = 1 - (np.linalg.norm(agent_pos - demo_positions, axis=1).min() / max_distance)
                    reward += demo_weight * similarity

        # 충돌 페널티
        if info.get("collision", False):
            reward -= 10

        # 관절 상태 기반 패널티 : 중복 계산이라서 뺌. 위에서 일단 함.
        #try:
            #joint_angles = self.arm.get_servo_angle()[1]
            #joint_penalty = sum(max(0, abs(angle) - limit) for angle, limit in zip(joint_angles, JOINT_LIMIT[0]))
            #reward -= 0.1 * joint_penalty
        #except Exception as e:
            #print(f"Joint angle error: {e}")

        # 목표 도달 시 큰 보상
        if info.get('is_success', False):
            reward += 10

        # 액션 크기 및 변화 패널티 - 액션 반영이 안되는것 같아서 넣어봄봄
        if action is not None:
            reward -= 0.001 * np.linalg.norm(action)
            if hasattr(self, 'prev_action'):
                action_diff = np.linalg.norm(action - getattr(self, 'prev_action', np.zeros_like(action)))
                reward -= 0.01 * action_diff
            self.prev_action = action

        # 상태 변화량 패널티 : 이거는 너무 크게 움직이면 넣자.
        # 로봇이 큰 변화 보이면 페널티 주는거. 불필요한 움직임 억제.
        # info 딕셔너리에도 넣긴 했음 (나중에 열어서 봐봐)
        #delta_state는 이전 관측값과 현재 관측값(관절 상태, 좌표 등)의 차이
        #np.linalg.norm(delta_state)는 벡터의 크기(즉, 상태 변화량)를 계산
        
        #고민하다가, 로봇이 너무 크게 흔들리고 난리칠까봐 일단 씀
        state_change = info.get('state_change', 0)
        if state_change > 0:
            reward -= 0.01 * state_change

        # 일관성 보상: 이전 거리 대비 현재 목표 거리 감소 시 보상
        if self.num_steps > 0:
            prev_distance = getattr(self, 'prev_distance', max_position_distance)
            consistency_reward = 0.01 * (prev_distance - position_distance)
            reward += consistency_reward
            self.prev_distance = position_distance

        # 리워드 클리핑
        return np.clip(reward, -10, 20)

    def render(self):
        pass

    def close(self):
        self.arm.disconnect()

    def _get_obs(self):
        angle_state = self.arm.get_servo_angle()[1]
        coordinates = self.arm.get_position(is_radian=False)[1]
        external_force = self.arm.ft_ext_force
        gripper_state = self.arm.get_suction_cup()

        obs = np.concatenate([angle_state, coordinates, gripper_state, external_force])
        return {
            'observation': obs.copy(),
            'achieved_goal': np.squeeze(coordinates.copy()),
            'desired_goal': self.goal.copy(),
        }

    def _sample_goal(self):
        goal = np.array(self.goal_space.sample())
        return goal

    def _is_success(self, achieved_goal, desired_goal):
        return np.linalg.norm(achieved_goal - desired_goal) < 0.1

if __name__ == "__main__":
    env = XArmEnv(use_demonstrations=True, max_episodes_for_demo=1000)
    obs = env.reset()
    print(obs)
    for _ in range(1000):
        action = env.action_space.sample()
        obs, reward, done, _, info = env.step(action)
        print(reward)
        if done:
            obs = env.reset()[0]
    env.close()

#env2는 데몬스트레이션 자체를 리워드로.
#env3는 데몬스트레이션 초기 탐색용용에 넣고, 이후는 제로샷 가능하게