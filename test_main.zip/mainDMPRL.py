from DMP8 import DMPTrainer
from env4 import XArmEnv
from run2 import RLTrainer
import os

class Main:
    def __init__(self):
        pass

    def main(self):
        print("=== Starting DMP Training ===")
        dmp_trainer = DMPTrainer()
        dmp_trainer.train()

        print("\n=== Running XArm Environment ===")
        xarm_env = XArmEnv()
        xarm_env.run()

        print("\n=== Starting RL Training ===")
        rl_trainer = RLTrainer()
        rl_trainer.train()

        print("\nAll tasks completed successfully!")

if __name__ == "__main__":
    m = Main()
    m.main()


"""
from DMP7 import train_dmp
from env4 import run_xarm_env
from run2 import train_rl

def main():
    print("=== Starting All Processes ===")
    
    # DMP 모델 학습 실행
    train_dmp()
    
    # XArm 환경 실행
    run_xarm_env()
    
    # RL 학습 실행
    train_rl()
    
    print("=== All Tasks Completed Successfully ===")

if __name__ == "__main__":
    main()

    """